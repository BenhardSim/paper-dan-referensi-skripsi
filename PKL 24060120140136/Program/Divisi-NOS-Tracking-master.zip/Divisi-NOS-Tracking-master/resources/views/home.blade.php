@extends('layouts.main')

@section('container')
    <div class="container align-items-center justify-content-center bg-white rounded p-5">
        <h1 class="text-center">Halaman Home</h1>
    </div>
@endsection

